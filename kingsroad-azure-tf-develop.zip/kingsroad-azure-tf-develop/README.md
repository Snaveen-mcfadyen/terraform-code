[![Build status]()
## Requirements 
```
terraform => 0.12.23
kubectl => v1.17.2
azure cli => 2.2.0
```
## Terraform init using shellscript to create storage account and keyvault
```
bin/init-az-tf.sh kingsroad
```
## Defining environment
```
export TF_VAR_client_id="XXXXXXXXXX"
export TF_VAR_client_secret="XXXXXXXXXXXXX"
```
## Defining Workspace
```
terraform workspace list
        * default
        kingsroad-dev
        kingsroad-prd
        kingsroad-qa
        
terraform workspace select kingsroad-dev
```
## Example terraform apply/destroy
```
terraform apply -var-file=config/dev/config.tfvars
terraform destroy -var-file=config/dev/config.tfvars
```
